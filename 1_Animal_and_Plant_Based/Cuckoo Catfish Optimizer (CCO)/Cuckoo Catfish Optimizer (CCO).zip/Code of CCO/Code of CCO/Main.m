%_________________________________________________________________________________
% 
%  CCO source code (Developed in MATLAB R2022b)
%  Paper:
%  Tian-Lei Wang, Shao-Wei Gu, Ren-Ju Liu, Le-Qing Chen, Zhu Wang, Zhi-Qiang Zeng, 
%  Cuckoo Catfish Optimizer: A New Meta-Heuristic Optimization Algorithm 
%  Artificial Intelligence Review 
%__________________________________________________________________________________

clc;
clear all;
close all;
MaxIteration=1000; 
PopSize=50;
FunIndex=1;
[BestX,BestF,HisBestF,FW_CCO,FA_CCO,SE_CCO]=CCO_code(FunIndex,MaxIteration,PopSize);

display(['F_index=', num2str(FunIndex)]);
display(['The FB_CCO is: ', num2str(mean(BestF))]);
display(['The FW_CCO is: ', num2str(mean(FW_CCO))]);
display(['The FA_CCO is: ', num2str(mean(FA_CCO))]);
display(['The SE_CCO is: ', num2str(mean(SE_CCO))]);

Optimal(FunIndex)=BestF;

display(['The best solution is: ', num2str(BestX)]);
 if BestF>=0
     semilogy(HisBestF,'r','LineWidth',2);
 else
     plot(HisBestF,'r','LineWidth',2);
 end
 xlabel('Iterations');
 ylabel('Fitness');
 title(['F',num2str(FunIndex)]);
