%_________________________________________________________________________________
%  Blood-Sucking Leech Optimizer                                                               
%                                                                                                     
%  Developed in MATLAB R2023b                                                                  
%                                                                                                     
%  programming: Jianfu Bai                                                          
%                                                                                                     
%  e-Mail: Jianfu.Bai@UGent.be, magd.abdelwahab@ugent.be                                                               
%  Soete Laboratory, Department of Electrical Energy, Metals, Mechanical Constructions, and Systems, 
%  Faculty of Engineering and Architecture, Ghent University, Belgium                                                           
%                                                                                                                                                                                                                                                              
%  paper: Jianfu Bai, H. Nguyen-Xuan, Elena Atroshchenko, Gregor Kosec, Lihua Wang, Magd Abdel Wahab, Blood-sucking leech optimizer[J]. Advances in Engineering Software, 2024, 195: 103696.
%  doi.org/10.1016/j.advengsoft.2024.103696
%____________________________________________________________________________________
clear all
clc

%benchmarksType = 1 for 23 Classical benchmark functions
%benchmarksType = 2 for CEC 2017
%benchmarksType = 3 for CEC 2019
benchmarksType = 1;

if benchmarksType == 1
    maxFunc = 23;
elseif benchmarksType == 2
    maxFunc = 30;
elseif benchmarksType == 3
    maxFunc = 10;
else
    exit;
end

SearchAgents_no = 30;
Max_iteration= 1000;
runs = 30;
for fn = 1:maxFunc
    
    Function_name=strcat('F',num2str(fn));
    if benchmarksType == 1
        [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
    elseif benchmarksType == 2
        if fn == 2
            continue;   %To skip function-2 of CEC-BC-2017 because of its unstable behavior
        end
        [lb,ub,dim,fobj]=CEC2017(Function_name);
    elseif benchmarksType == 3
        [lb,ub,dim,fobj]=CEC2019(Function_name);
    end
    
    Best_score_T = zeros(runs,1);
    AvgConvCurve = zeros(Max_iteration,1);
    Convergence_curve=zeros(runs,Max_iteration);

    Leeches_x=zeros(1,Max_iteration*SearchAgents_no);
    Leeches_y=zeros(1,Max_iteration*SearchAgents_no);
    %Execute the BSLO algorithm
    for run=1:runs
        [Best_score,Best_pos,cg_curve]=BSLO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
        Best_score_T(run) = Best_score;       
    end
    
    Best_score_Best = min(Best_score_T);
    Best_Score_Mean = mean(Best_score_T);
    Best_Score_std = std(Best_score_T);
    %output
    format long
    display([Function_name, ' Best:  ', num2str(Best_score_Best), '     ', 'Mean:  ', num2str(Best_Score_Mean), '     ', 'Std. Deviation:  ', num2str(Best_Score_std)]);
end