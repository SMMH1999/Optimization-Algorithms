% Define the objective function (Sphere Function)
function f = sphere_function(x)
    f = sum(x.^2);
end

