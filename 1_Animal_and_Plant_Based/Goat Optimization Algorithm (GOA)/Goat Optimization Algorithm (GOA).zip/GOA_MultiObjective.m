function [bestSolution, bestFitness] = GOA_MultiObjective(dim, N, maxIter, lb, ub)
% Goat Optimization Algorithm (GOA) for Multi-Objective Optimization
% Parameters:
% dim: Dimension of the problem
% N: Number of goats (population size)
% maxIter: Maximum number of iterations
% lb: Lower bound (vector)
% ub: Upper bound (vector)

% Initialize population
pop = repmat(lb, N, 1) + rand(N, dim) .* (repmat(ub - lb, N, 1));
fitness = arrayfun(@(i) objectiveFunction(pop(i, :)), 1:N)';
[bestFitness, bestIdx] = min(fitness);
bestSolution = pop(bestIdx, :);

alpha = 0.05; % Exploration coefficient
beta = 0.5;  % Exploitation coefficient
J = 0.1;     % Jump coefficient

for t = 1:maxIter
    for i = 1:N
        r1 = rand();
        r2 = rand();
        r3 = rand();

        % Exploration
        if r1 < 0.5
            pop(i, :) = pop(i, :) + alpha * randn(1, dim) .* (ub - lb);
        end

        % Exploitation
        if r2 >= 0.5
            pop(i, :) = pop(i, :) + beta * (bestSolution - pop(i, :));
        end

        % Jump strategy
        if r3 < J
            randIdx = randi([1, N]);
            pop(i, :) = pop(i, :) + J * (pop(randIdx, :) - pop(i, :));
        end

        % Apply constraints
        pop(i, :) = min(max(pop(i, :), lb), ub);
    end

    % Evaluate fitness
    fitness = arrayfun(@(i) objectiveFunction(pop(i, :)), 1:N)';

    % Parasite avoidance (replace weakest 20%)
    [~, sortedIdx] = sort(fitness);
    weakest = sortedIdx(end - floor(0.2 * N) + 1:end);
    pop(weakest, :) = repmat(lb, length(weakest), 1) + rand(length(weakest), dim) .* (repmat(ub - lb, length(weakest), 1));

    % Update best solution
    [currentBestFitness, bestIdx] = min(fitness);
    if currentBestFitness < bestFitness
        bestFitness = currentBestFitness;
        bestSolution = pop(bestIdx, :);
    end
end
end

% Define the multi-objective optimization function
function f = objectiveFunction(x)
% Example: multi-objective function with constraints
% Objective: minimize f1 = sum(x.^2) and f2 = sum(abs(x))
% Constraints: sum(x) <= 10; each element >= 0

if sum(x) > 10 || any(x < 0)
    f = 1e6; % Penalty for constraint violation
else
    f1 = sum(x.^2);
    f2 = sum(abs(x));
    f = 0.5 * f1 + 0.5 * f2; % Combine objectives into a single scalar
end
end

% Example usage:
% dim = 5; N = 30; maxIter = 100;
% lb = zeros(1, dim);
% ub = ones(1, dim) * 5;
% [bestSol, bestFit] = GOA_MultiObjective(dim, N, maxIter, lb, ub);
% disp('Best Solution:'), disp(bestSol);
% disp('Best Fitness:'), disp(bestFit);")}
