% CEC2017

clc;clear;close all

func_num = 1;
D=30;
Xmin=-100;
Xmax=100;
pop_size=50;
iter_max=500;
fhd = @(x) cec17_func(x',func_num) ;
disp(['F',num2str(func_num),' Dim: ',num2str(D)])

disp('DMO is now tackling your problem')
[BEF_DMO,BEP_DMO,BestCost_DMO]=DMO(pop_size,iter_max,Xmin,Xmax,D,fhd);
disp('EDMO is now tackling your problem')
[BEF_EDMO,BEP_EDMO,BestCost_EDMO]=EDMO(pop_size,iter_max,Xmin,Xmax,D,fhd);



semilogy(BestCost_DMO, '-','Color',[0 0.8 0.2],'LineWidth',2)  % �Զ�����ɫ2
hold on
semilogy(BestCost_EDMO, '-','Color',[1 0 0],'LineWidth',2)  % ��ɫ
CurveTitle=['CEC2017-F',num2str(func_num),' (Dim=',num2str(D),')'];
title(CurveTitle)
xlabel('Iteration#');
ylabel('Best Fitness Value');
legend('DMO','EDMO')
axis tight
box on
set(gca,'FontSize',12,'Fontname', 'Times New Roman');
display(['The best optimal values of the objective funciton found by DMO is : ', num2str(BEF_DMO)]);
display(['The best optimal values of the objective funciton found by EDMO is : ', num2str(BEF_EDMO)]);
