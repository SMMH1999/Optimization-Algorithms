function [BEF,BEP,BestCost]=EDMO(nPop,MaxIt,VarMin,VarMax,nVar,F_obj)
% EDMOA: Enhanced Dwarf Mongoose Optimization Algorithm
% 增强策略：OLOBL（正交折射对立）+ DQTOS（动态量子隧穿）+ BDFSS（仿生趋光动态聚焦）
% 接口与原始 DMOA 保持一致。

VarSize=[1 nVar];

% ====== 基本设置（与原 DMO 一致）======
nBabysitter=3;
nAlphaGroup=nPop-nBabysitter;
nScout=nAlphaGroup;
L=round(0.6*nVar*nBabysitter);
peep=2;  % Alpha female vocalization

% ====== 结构体与初始化 ======
empty_mongoose.Position=[];
empty_mongoose.Cost=[];
pop=repmat(empty_mongoose,nAlphaGroup,1);

BestSol.Cost=inf;
tau=inf;
sm=inf(nAlphaGroup,1);

for i=1:nAlphaGroup
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Position=project_bounds(pop(i).Position,VarMin,VarMax);
    pop(i).Cost=F_obj(pop(i).Position);
    if pop(i).Cost<=BestSol.Cost
        BestSol=pop(i);
    end
end

C=zeros(nAlphaGroup,1);
BestCost=zeros(MaxIt,1);

% ====== EDMOA 主循环 ======
for it=1:MaxIt
    
    % --- Alpha group：Roulette 选择 + 觅食 ---
    F=zeros(nAlphaGroup,1);
    MeanCost = mean([pop.Cost]);
    for i=1:nAlphaGroup
        F(i)=exp(-pop(i).Cost/(MeanCost+eps));
    end
    P=F/sum(F);
    
    for m=1:nAlphaGroup
        i = RouletteWheelSelection(P);
        K=[1:i-1 i+1:nAlphaGroup];
        k = K(randi([1 numel(K)]));
        phi=(peep/2)*unifrnd(-1,+1,VarSize);
        newpop.Position=pop(i).Position + phi.*(pop(i).Position - pop(k).Position);
        newpop.Position=project_bounds(newpop.Position,VarMin,VarMax);
        newpop.Cost=F_obj(newpop.Position);
        if newpop.Cost<=pop(i).Cost
            pop(i)=newpop;
        else
            C(i)=C(i)+1;
        end
    end
    
    % --- Scout group：与原版一致的第一阶段 ---
    for i=1:nScout
        K=[1:i-1 i+1:nAlphaGroup];
        k=K(randi([1 numel(K)]));
        phi=(peep/2)*unifrnd(-1,+1,VarSize);
        newpop.Position=pop(i).Position + phi.*(pop(i).Position - pop(k).Position);
        newpop.Position=project_bounds(newpop.Position,VarMin,VarMax);
        newpop.Cost=F_obj(newpop.Position);
        
        % Sleeping mould
        sm(i)=(newpop.Cost-pop(i).Cost)/max(newpop.Cost,pop(i).Cost);
        
        if newpop.Cost<=pop(i).Cost
            pop(i)=newpop;
        else
            C(i)=C(i)+1;
        end
    end
    
    % --- Babysitters（换岗/重置）---
    for i=1:nBabysitter
        if C(i)>=L
            pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
            pop(i).Position=project_bounds(pop(i).Position,VarMin,VarMax);
            pop(i).Cost=F_obj(pop(i).Position);
            C(i)=0;
        end
    end
    
    % --- 更新全局最优 ---
    for i=1:nAlphaGroup
        if pop(i).Cost<=BestSol.Cost
            BestSol=pop(i);
        end
    end
    
    % --- 原版“下一位置”/方向控制（使用 CF 与 tau）---
    CF=(1-it/MaxIt)^(2*it/MaxIt);
    newtau=mean(sm(~isinf(sm)));
    if isempty(newtau) || isnan(newtau), newtau=0; end
    for i=1:nScout
        phi=(peep/2)*unifrnd(-1,+1,VarSize);  % 确保已定义
        M=(pop(i).Position.*sm(i))./(pop(i).Position+eps);
        if newtau>tau
            cand=pop(i).Position - CF.*phi.*rand(size(phi)).*(pop(i).Position - M);
        else
            cand=pop(i).Position + CF.*phi.*rand(size(phi)).*(pop(i).Position - M);
        end
        tau=newtau;
        cand=project_bounds(cand,VarMin,VarMax);
        candCost=F_obj(cand);
        if candCost<=pop(i).Cost
            pop(i).Position=cand;
            pop(i).Cost=candCost;
        end
    end
    
    % ====== (A) OLOBL：仅对当前全局最优个体进行 ======
    [oloblPos,oloblCost]=olobl_leader(BestSol.Position,VarMin,VarMax,nVar,it,MaxIt,F_obj);
    if oloblCost < BestSol.Cost
        BestSol.Position=oloblPos; BestSol.Cost=oloblCost;
        % 将改进过的领袖注入群体（替换当前最差个体）
        [~,worstIdx]=max([pop.Cost]);
        pop(worstIdx)=BestSol;
    end
    
    % ====== (B) BDFSS：在 Scout 后做一次“趋光聚焦”细化 ======
    % 光强映射 I \in [0,1]；alpha_i ~ [0.1,0.9]
    costs=[pop.Cost];
    fbest=min(costs); fworst=max(costs);
    if fbest==fworst, fworst=fbest+1e-12; end
    I = (fworst - costs) ./ (fworst - fbest + eps);  % 成绩越好，I 越接近 1
    Imax=1;
    alpha_min=0.1; alpha_max=0.9;
    alphas = alpha_min + (alpha_max-alpha_min).*(I./Imax);
    
    delta=0.01*(VarMax-VarMin);
    for i=1:nScout
        % 数值梯度（中心差分）
        grad=zeros(VarSize);
        for d=1:nVar
            e=zeros(VarSize); e(d)=1;
            xp=project_bounds(pop(i).Position + delta.*e,VarMin,VarMax);
            xm=project_bounds(pop(i).Position - delta.*e,VarMin,VarMax);
            Ip = (fworst - F_obj(xp)) / (fworst - fbest + eps);
            Im = (fworst - F_obj(xm)) / (fworst - fbest + eps);
            grad(d)=(Ip - Im)/(2*delta);
        end
        % 社会项：朝当代最优靠拢 + 随机微扰
        social = (BestSol.Position - pop(i).Position);
        xi = rand();  % 光敏响应权重系数
        phi_local = unifrnd(0,1,VarSize);
        cand = pop(i).Position + phi_local.*(social + xi.*alphas(i).*grad);
        cand=project_bounds(cand,VarMin,VarMax);
        candCost=F_obj(cand);
        if candCost < pop(i).Cost
            pop(i).Position=cand;
            pop(i).Cost=candCost;
            if candCost < BestSol.Cost
                BestSol=pop(i);
            end
        end
    end
    
    % ====== (C) DQTOS：对全体个体尝试“量子隧穿” ======
    costs=[pop.Cost];
    fbest=min(costs); fworst=max(costs);
    V0=0.5;                           % 初始势垒基准
    tau_q = 0.1*MaxIt;                % 温度衰减时间常数
    Tt = 1/(1+exp(it/tau_q));         % 温度/探索强度
    Delta = (VarMax-VarMin)/2 .* (1 - it/MaxIt)^2;   % 动态步长（向收敛衰减）
    beta = 1;                          % 隧穿尺度系数
    
    for i=1:nAlphaGroup
        Vi = abs(pop(i).Cost - fbest) / (fworst - fbest + eps) * V0;
        Ek = Tt + eps;                 % 把温度当作等效“动能”
        % 隧穿概率（柔性实现）：当 V/Ek 较小概率更大
        Pt = exp(-max(0,Vi/Ek));
        if rand < Pt
            % 隧穿方向：以高斯微扰为主，微量朝 global best 方向
            dir = 0.7*randn(VarSize) + 0.3*(BestSol.Position - pop(i).Position);
            cand = pop(i).Position + beta.*Tt.*Delta.*dir;
            cand=project_bounds(cand,VarMin,VarMax);
            candCost=F_obj(cand);
            if candCost < pop(i).Cost
                pop(i).Position=cand;
                pop(i).Cost=candCost;
                if candCost < BestSol.Cost
                    BestSol=pop(i);
                end
            end
        end
    end
    
    % --- 记录 ---
    BestCost(it)=BestSol.Cost;
    BEF=BestSol.Cost;
    BEP=BestSol.Position;
end
end

% ================== 辅助函数们 ==================

function i=RouletteWheelSelection(P)
    r=rand; C=cumsum(P);
    i=find(r<=C,1,'first');
end

function x=project_bounds(x,lb,ub)
    x = min(max(x,lb),ub);
end

function [bestPos,bestCost]=olobl_leader(x,lb,ub,D,t,Tmax,F_obj)
% OLOBL：折射对立 + 正交（近似）子维度组合，仅对领袖做少量评估
% 生成 M=2*log2(D+1) 个候选，择优返回
    M = max(4, 2*ceil(log2(D+1)));
    candPos = zeros(M,D);
    candCost = inf(M,1);
    
    % 折射“对立点” X'（随迭代调整强度）
    k = (1 + (t/max(1,Tmax))^2)^10;
    mid = (ub+lb)/2;
    x_reflect = mid + mid./k - x./k;          % 对应公式的等价线性变换
    x_reflect = project_bounds(x_reflect,lb,ub);
    
    % 维度掩码的近似正交采样（轻量）：利用 Halton/随机二进制子集
    rng('shuffle');
    for m=1:M
        mask = rand(1,D) > 0.5;               % 约半数维度取对立
        xp = x;
        xp(mask) = x_reflect(mask);
        xp = project_bounds(xp,lb,ub);
        candPos(m,:) = xp;
        candCost(m) = F_obj(xp);
    end
    
    % 原点也参与比较（无需重复评估）
    [bestCost,idx] = min([F_obj(x), candCost']);
    if idx==1
        bestPos = x;
    else
        bestPos = candPos(idx-1,:);
    end
end
