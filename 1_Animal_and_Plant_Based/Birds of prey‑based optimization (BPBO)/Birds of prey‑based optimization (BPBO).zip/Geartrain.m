

%__________________________________________________________________     %
%                Birds of prey-based optimization (BPBO)                %
%                                                                       %
%                                                                       %
%                  Developed in MATLAB R2024b (MacOs)                   %
%                                                                       %
%                      Author and programmer                            %
%                                                                       %
%                ---------------------------------                      %
%                          Mojtaba Ghasemi                              %
%     Co:   Nima Khodadadi (ʘ‿ʘ) University of California Berkeley      %
%                             e-Mail                                    %
%                ---------------------------------                      %
%                      Nimakhan@berkeley.edu                            %
%                                                                       %
%                                                                       %
%                            Homepage                                   %
%                ---------------------------------                      %
%                    https://nimakhodadadi.com                          %
%                                                                       %
%                                                                       %
%                                                                       %
%                                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           Citation                                    %
% Ghasemi, M., Akbari, M.A., Zare, M. et al. Birds of prey-based        %
% optimization (BPBO): a metaheuristic algorithm for optimization.      %
% Evol. Intel. 18, 88 (2025).                                           %
% https://doi.org/10.1007/s12065-025-01052-8                            %
% ----------------------------------------------------------------------%


% Geartrain
function z = Geartrain(x)

% x=x*10000000000;
% x=round(x);
% x=x/10000000000;
x1=round(x(1));
x2=round(x(2));
x3=round(x(3));
x4=round(x(4));

 z=((1/6.931)-((x2*x3)/(x1*x4)))^2;