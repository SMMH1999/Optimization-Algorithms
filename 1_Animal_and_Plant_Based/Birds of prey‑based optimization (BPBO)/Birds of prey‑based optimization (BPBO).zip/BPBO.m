
%__________________________________________________________________     %
%                Birds of prey-based optimization (BPBO)                %
%                                                                       %
%                                                                       %
%                  Developed in MATLAB R2024b (MacOs)                   %
%                                                                       %
%                      Author and programmer                            %
%                                                                       %
%                ---------------------------------                      %
%                          Mojtaba Ghasemi                              %
%     Co:   Nima Khodadadi (ʘ‿ʘ) University of California Berkeley      %
%                             e-Mail                                    %
%                ---------------------------------                      %
%                      Nimakhan@berkeley.edu                            %
%                                                                       %
%                                                                       %
%                            Homepage                                   %
%                ---------------------------------                      %
%                    https://nimakhodadadi.com                          %
%                                                                       %
%                                                                       %
%                                                                       %
%                                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           Citation                                    %
% Ghasemi, M., Akbari, M.A., Zare, M. et al. Birds of prey-based        %
% optimization (BPBO): a metaheuristic algorithm for optimization.      %
% Evol. Intel. 18, 88 (2025).                                           %
% https://doi.org/10.1007/s12065-025-01052-8                            %
% ----------------------------------------------------------------------%


clc;
clear all;

for trr=1
    Nf=trr;

for iijj=1:30

format long
%% Problem Definition
CostFunction = @(x)  Geartrain(x);

%%%%%%%%%%%%%Geartrain
VarMin =[12 12 12 12];       % Unknown Variables Lower Bound[25 25 0.0625 0.0625];  
VarMax =  [60 60 60 60];       % Unknown Variables Upper Bound[150 240 1.25 1.25]; 

nVar =size(VarMin,2);          % Number of Unknown Variables
VarSize = [1 nVar]; % Decision Variables Matrix Size

% VarMin = 0;       % Lower Bound of Decision Variables
% VarMax =1 ;        % Upper Bound of Decision Variables

%% BPBO Parameters

MaxIt = 1000;    % Maximum Number of Iterations
 Pi=0.7;

nPop =90;           % Population Size

%% Initialization 

% Empty Structure for Individuals
empty_individual.Position = [];
empty_individual.Cost = [];

% Initialize Population Array
pop = repmat(empty_individual, nPop, 1);

% Initialize Best Solution
Prey.Cost = inf;

% Initialize Population Members
for i=1:nPop
    pop(i).Position = unifrnd(VarMin, VarMax, VarSize);
     pop(i).Cost = CostFunction(pop(i).Position);

    if pop(i).Cost < Prey.Cost
       Prey = pop(i);
    end
    BestCost1(i)=Prey.Cost;
end

% Initialize Best Cost Record
BestCosts = zeros(MaxIt,1);

%% BPBO Main Loop
%  it=nPop;
it=0;
 for it=1:MaxIt
% while it<=(MaxIt-nPop)
    
    % Calculate Population Mean
    Mean = 0;
    for i=1:nPop
        Mean = Mean + pop(i).Position;
    end
    Mean = Mean/nPop;
    
    % Select Prey
    Prey = pop(1);
 
    for i=2:nPop
        if pop(i).Cost < Prey.Cost
            Prey = pop(i);
               end
    end
    
     
    for i=1:nPop
        % Create Empty Solution
        newsol = empty_individual;
     
     
      if rand<Pi
            if rand<rand
            M00=round(1+rand);
        newsol.Position = pop(i).Position ...
           + rand(VarSize).*(Prey.Position- M00*pop(i).Position);
        elseif rand<rand
             M01=round(1+rand);
              newsol.Position = Mean ...
            +rand(VarSize).*(Prey.Position -M01*Mean); 
            else
                          
               M02=round(1+rand);
              newsol.Position = pop(i).Position ...
            +rand(VarSize).*(pop(i).Position- M02*pop(nPop).Position); 
            end
        else

            newsol.Position =pop(i).Position+rand*( unifrnd(VarMin, VarMax, VarSize)); 

        
    end
        % Evaluation 
       newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
         newsol.Cost = CostFunction(newsol.Position);

           if newsol.Cost<pop(i).Cost
            pop(i) = newsol;
             if pop(i).Cost < Prey.Cost
            Prey = pop(i);
                      end
        end
%           it=it+1; 

  BestCost1(it)=Prey.Cost;
    end
% Sort Swarm
    [uuu, SortOrder]=sort([pop.Cost]);
    pop = pop(SortOrder);
   
    % Store Record for Current Iteration
 Curve(it) =pop(1).Cost;
 % Iteration Information
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str( Curve(it))]);
    
    
end

%% Results
  Cost_Rsult(1, iijj)=Prey.Cost;
 Rsult(iijj,:)=BestCost1; 
end

trr
Meann(trr)=mean(Cost_Rsult)
Bestt(trr)=min(Cost_Rsult)
Worstt(trr)=max(Cost_Rsult)
Stdd(trr)=std(Cost_Rsult)
 hold on
plot((mean(Rsult)),'k','LineWidth',4); hold on
end
