%%  Multi-strategy Improved Black-winged Kite Algorithm
function [Best_Fitness_MSBKA,Best_Pos_MSBKA,Convergence_curve]=MSBKA(T,pop,lb,ub,dim,fobj)
%% ---------------- Initialize the locations using Tent mapping ---------------- %
p = 0.9;
r = rand;

% --- Tent chaotic initialization ---
XPos = Tent_initialization(pop, dim, lb, ub);

for i = 1:pop
    XFit(i) = fobj(XPos(i,:));
end

Convergence_curve = zeros(1, T);
%% -------------------Start iteration------------------------------------%
for t=1:T
    [~,sorted_indexes]=sort(XFit);
    XLeader_Pos=XPos(sorted_indexes(1),:);
    XLeader_Fit = XFit(sorted_indexes(1));
%% -------------------Attacking behavior-------------------%
% 动态调整攻击概率p，线性递减
    p = 0.9 * (1 - t/T);  % 从0.9递减到0
r=rand;    
for i=1:pop
        n=0.05*exp(-2*(t/T)^2);
         % 生成莱维飞行步长（需实现levyFlight函数）
        levy_step = levyFlight(dim);
        
        % 生成柯西随机数
        cauchy_step = trnd(1, 1, dim);
        
        if p < rand  % 使用动态概率   
            % 策略1：莱维飞行引导的全局搜索
            XPosNew(i,:) = XPos(i,:) + n.*levy_step.*(XLeader_Pos - XPos(i,:));
        else
            % 策略2：差分变异增强局部开发
            % 随机选择三个不同个体
            r1 = randi(pop);
            r2 = randi(pop);
            r3 = randi(pop);
            while r1==r2 || r1==r3 || r2==r3
                r1 = randi(pop); r2 = randi(pop); r3 = randi(pop);
            end
            F = 0.5 + 0.3*sin(pi*t/T);  % 动态缩放因子
            XPosNew(i,:) = XPos(r1,:) + F*(XPos(r2,:) - XPos(r3,:));
            
            % 加入最优解扰动
            XPosNew(i,:) = XPosNew(i,:) + 0.1*cauchy_step.*(XLeader_Pos - XPosNew(i,:));
        end
        
        % 反射边界处理（需实现reflectBounds函数）
        XPosNew(i,:) = reflectBounds(XPosNew(i,:), lb, ub);
%% ------------ Select the optimal fitness value--------------%
        XFit_New(i)=fobj(XPosNew(i,:));
        if(XFit_New(i)<XFit(i))
            XPos(i,:) = XPosNew(i,:);
            XFit(i) = XFit_New(i);
        end
%% -------------------Migration behavior-------------------%
         m=2*sin(r+pi/2);
         golden_ratio = 0.5*(sqrt(5)-1); % 黄金分割比例
            x1 = -pi + (1 - golden_ratio)*2*pi;
            x2 = -pi + golden_ratio*2*pi;       
            s = randi([1, pop]); % 随机选择参考个体
            
            % 生成随机参数
            R1 = rand() * pi;    % [0, π]随机角
            R2 = rand() * 2 * pi; % [0, 2π]随机角
        s = randi([1,30],1);
        r_XFitness=XFit(s);
        ori_value = rand(1,dim);cauchy_value = tan((ori_value-0.5)*pi);
        if XFit(i)< r_XFitness
            XPosNew(i,:)=XPos(i,:)+R2*sin(R1)*cauchy_value(:,dim).* (x1*XPos(i,:)-x2*XLeader_Pos);
        else
            XPosNew(i,:)=XPos(i,:)+cauchy_value(:,dim).* (XLeader_Pos-m.*XPos(i,:));
        end
        XPosNew(i,:) = max(XPosNew(i,:),lb);XPosNew(i,:) = min(XPosNew(i,:),ub); %%Boundary checking
%% --------------  Select the optimal fitness value---------%
        XFit_New(i)=fobj(XPosNew(i,:));
        if(XFit_New(i)<XFit(i))
            XPos(i,:) = XPosNew(i,:);
            XFit(i) = XFit_New(i);
        end
    end
    %% -------Update the optimal Black-winged Kite----------%
    if(XFit<XLeader_Fit)
        Best_Fitness_MSBKA=XFit(i);
        Best_Pos_MSBKA=XPos(i,:);
    else
        Best_Fitness_MSBKA=XLeader_Fit;
        Best_Pos_MSBKA=XLeader_Pos;
    end
    Convergence_curve(t)=Best_Fitness_MSBKA;
end
end
%% -------------------Embedded Auxiliary Functions-------------------%

function positions = reflectBounds(positions, lb, ub)
    % Reflect boundary handling
    for j = 1:length(positions)
        if positions(j) < lb(j)
            positions(j) = 2 * lb(j) - positions(j);
        elseif positions(j) > ub(j)
            positions(j) = 2 * ub(j) - positions(j);
        end
        % Secondary reflection handling
        positions(j) = min(max(positions(j), lb(j)), ub(j));
    end
end

function step = levyFlight(d)
    % Levy flight step generation
    beta = 1.5;
    sigma = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2^((beta - 1) / 2)))^(1 / beta);
    u = randn(1, d) * sigma;
    v = randn(1, d);
    step = u ./ abs(v).^(1 / beta);
end

function Positions = Tent_initialization(SearchAgents_no, dim, lb, ub)
% Tent chaotic map based initialization

Positions = zeros(SearchAgents_no, dim);
epsilon = 1e-10;

for i = 1:SearchAgents_no
    % Random initial seed (avoid 0.5)
    x = rand;
    while abs(x - 0.5) < epsilon
        x = rand;
    end

    for j = 1:dim
        % Tent mapping
        if x < 0.5
            x = 2 * x;
        else
            x = 2 * (1 - x);
        end
        x = min(max(x, epsilon), 1 - epsilon);
        Positions(i,j) = lb(j) + x * (ub(j) - lb(j));
    end
end
end