% CEC2017

clc;clear;close all

func_num = 30;
D=30;
Xmin=-100;
Xmax=100;
pop_size=30;

iter_max=500;
fhd=str2func('cec17_func');
disp(['F',num2str(func_num),' Dim: ',num2str(D)])


disp('DBO is now tackling your problem')
[BEF_DBO,BEP_DBO,BestCost_DBO]=DBO(pop_size,iter_max,Xmin,Xmax,D,fhd,func_num);
disp('ENMDBO is now tackling your problem')
[BEF_ENMDBO,BEP_ENMDBO,BestCost_ENMDBO]=ENMDBO(pop_size,iter_max,Xmin,Xmax,D,fhd,func_num);

%��ͼ
semilogy(BestCost_DBO, '-','Color',[0.7 0.7 0.7],'LineWidth',2)  % �Զ�����ɫ4
hold on
semilogy(BestCost_ENMDBO, '-','Color',[1 0 0],'LineWidth',2)  % ��ɫ
CurveTitle=['CEC2017-F',num2str(func_num),' (Dim=',num2str(D),')'];
title(CurveTitle)
xlabel('Iteration#');
ylabel('Best Fitness Value');
legend('DBO','ENMDBO')
axis tight
% grid on
box on
set(gca,'FontSize',12,'Fontname', 'Times New Roman');
display(['The best optimal values of the objective funciton found by DBO is : ', num2str(BEF_DBO)]);
display(['The best optimal values of the objective funciton found by ENMDBO is : ', num2str(BEF_ENMDBO)]);
