%%  Clear workspace
clear
clc
close all

%% Initial settings
addpath(genpath(pwd));

pop_size = 100;    % Population size
max_iter = 500;    % Maximum number of iterations
run = 2;           % Number of runs (at least 30 runs are recommended for statistical significance)

F = 6;             % Test function index
variables_no = 30; % Dimension: optional 2, 10, 30, 50, 100

disp(['Statistics are performed on CEC2017 function set with dimension ', num2str(variables_no)])
disp(['F', num2str(F),])

%% Get test function
func_num = F;
[lower_bound, upper_bound, variables_no, fobj] = Get_Functions_cec2017(func_num, variables_no);
lower_bound = lower_bound .* ones(1, variables_no);
upper_bound = upper_bound .* ones(1, variables_no);

%% Run RLQFAO algorithm
disp('Running RLQFAO algorithm...')
final_RLQFAO = zeros(1, run);
Convergence_curve_RLQFAO = zeros(run, max_iter);

for nrun = 1:run
    [final, position, iter] = RLQFAO(pop_size, max_iter, lower_bound, upper_bound, variables_no, fobj);
    final_RLQFAO(nrun) = final;
    Convergence_curve_RLQFAO(nrun, :) = iter;
    fprintf('RLQFAO run %d/%d completed\n', nrun, run);
end

% Statistics of RLQFAO results
stats_RLQFAO = [
    min(final_RLQFAO);      % Best value
    std(final_RLQFAO);      % Standard deviation
    mean(final_RLQFAO);     % Mean value
    median(final_RLQFAO);   % Median value
    max(final_RLQFAO)       % Worst value
];

disp('========== RLQFAO Results ==========')
fprintf('Best value:   %.6e\n', stats_RLQFAO(1));
fprintf('Std. dev.:    %.6e\n', stats_RLQFAO(2));
fprintf('Mean value:   %.6e\n', stats_RLQFAO(3));
fprintf('Median value: %.6e\n', stats_RLQFAO(4));
fprintf('Worst value:  %.6e\n', stats_RLQFAO(5));

%% Run AO algorithm
disp('Running AO algorithm...')
final_AO = zeros(1, run);
Convergence_curve_AO = zeros(run, max_iter);

for nrun = 1:run
    [final, position, iter] = AO(pop_size, max_iter, lower_bound, upper_bound, variables_no, fobj);
    final_AO(nrun) = final;
    Convergence_curve_AO(nrun, :) = iter;
    fprintf('AO run %d/%d completed\n', nrun, run);
end

% Statistics of AO results
stats_AO = [
    min(final_AO);      % Best value
    std(final_AO);      % Standard deviation
    mean(final_AO);     % Mean value
    median(final_AO);   % Median value
    max(final_AO)       % Worst value
];

disp('========== AO Results ==========')
fprintf('Best value:   %.6e\n', stats_AO(1));
fprintf('Std. dev.:    %.6e\n', stats_AO(2));
fprintf('Mean value:   %.6e\n', stats_AO(3));
fprintf('Median value: %.6e\n', stats_AO(4));
fprintf('Worst value:  %.6e\n', stats_AO(5));

%% Plot convergence curves
figure('Name', 'Convergence Curve Comparison', 'Color', 'w', 'Position', [100 100 800 600]);

% Compute mean convergence curves
mean_curve_RLQFAO = mean(Convergence_curve_RLQFAO, 1);
mean_curve_AO = mean(Convergence_curve_AO, 1);

% Set colors
color_RLQFAO = [1, 0, 0];       % Red
color_AO = [0.75, 0, 0.75];     % Purple

% Plot curves
semilogy(1:max_iter, mean_curve_RLQFAO, '-o', 'Color', color_RLQFAO, ...
    'LineWidth', 2, 'MarkerSize', 6, 'MarkerIndices', 1:10:max_iter);
hold on;

semilogy(1:max_iter, mean_curve_AO, '-s', 'Color', color_AO, ...
    'LineWidth', 2, 'MarkerSize', 6, 'MarkerIndices', 1:10:max_iter);

% Legend and labels
legend('RLQFAO', 'AO', 'Location', 'best', 'FontSize', 12);
title(['CEC2017-F', num2str(func_num), ' (Dim=', num2str(variables_no), ')'], 'FontSize', 14);
xlabel('Iteration', 'FontSize', 12);
ylabel('Mean Fitness Value', 'FontSize', 12);
grid on;
box on;
axis tight;
hold off;
