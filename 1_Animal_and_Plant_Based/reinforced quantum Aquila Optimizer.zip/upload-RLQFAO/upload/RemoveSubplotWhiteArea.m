
function [] = RemoveSubplotWhiteArea(gca, sub_row, sub_col, current_row, current_col)

sub_axes_x = current_col*1/sub_col - 1/sub_col;
sub_axes_y = 1-current_row*1/sub_row; 
sub_axes_w = 1/sub_col;
sub_axes_h = 1/sub_row;
set(gca, 'OuterPosition', [sub_axes_x, sub_axes_y, sub_axes_w, sub_axes_h]);
 

inset_vectior = get(gca, 'TightInset');
inset_x = inset_vectior(1);
inset_y = inset_vectior(2);
inset_w = inset_vectior(3);
inset_h = inset_vectior(4);
 

outer_vector = get(gca, 'OuterPosition');
pos_new_x = outer_vector(1) + inset_x; 
pos_new_y = outer_vector(2) + inset_y;
pos_new_w = outer_vector(3) - inset_w - inset_x; 
pos_new_h = outer_vector(4) - inset_h - inset_y; 
 

set(gca, 'Position', [pos_new_x, pos_new_y, pos_new_w, pos_new_h]);