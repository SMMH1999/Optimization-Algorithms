clear all;
clc;
close all;

format long g

objective_function=@fun;
constraints=@Constraints;

for k=1:1  % Number of independent runds
    %==========================================================================
    % Problem 1
    % nvars=7;
    % LB=[-10 -10 -10 -10 -10 -10 -10];
    % UB=[10 10 10 10 10 10 10];
    %==========================================================================
    % Problem 2
    % nvars=5;
    % LB=[78 33 27 27 27];
    % UB=[102 45 45 45 45];
    %==========================================================================
    % Problem 3
    % nvars=10;
    % LB=ones(1,nvars)*0;
    % UB=ones(1,nvars)*1;
    %==========================================================================
    % Problem 4
    % nvars=3;
    % LB=ones(1,nvars)*0;
    % UB=ones(1,nvars)*10;
    %==========================================================================
    % Three-bar truss problem
    % nvars=2;
    % LB=[0 0];
    % UB=[1 1];
    %==========================================================================
    % Speed reducer problem
    nvars=7;
    LB=[2.6 0.7 17 7.3 7.3 2.9 5];
    UB=[3.6 0.8 28 8.3 8.3 3.9 5.5];
    %==========================================================================
    % Pressure vessel problem
    % nvars=4;
    % LB=[0 0 10 10];
    % UB=[100 100 200 200];
    %==========================================================================
    % Tension/compression spring design problem
    % nvars=3;
    % LB=[0.05 0.25 2];
    % UB=[2 1.3 15];
    %==========================================================================
    % Welded beam problem
    % nvars=4;
    % LB=[0.1 0.1 0.1 0.1];
    % UB=[2 10 10 2];
    %==========================================================================
    % Rolling Element Bearing
    % nvars=10;
    % D=160;
    % d=90;
    % LB=[0.5*(D+d) 0.15*(D-d) 4 0.515 0.515 0.4 0.6 0.3 0.02 0.6];
    % UB=[0.6*(D+d) 0.45*(D-d) 50 0.6 0.6 0.5 0.7 0.4 0.1 0.85];
    %==========================================================================
    % Multiple disk clutch brake
    % nvars=5;
    %--------------Info
    % % ri=[60,21,21,...,80]; x(1)
    % % ro=[90,91,92,...,110]; x(2)
    % % t=[1,1.5,2,2.5,3]; x(3)
    % % F=[600,610, 620,...,1000]; x(4)
    % % Z=[2,3,4,5,6,7,8,9]; x(5)
    %-------------
    % LB=[60 90 1 2];
    % UB=[80 110 3 9];
    
    [Xmin,Fmin,SUM_Constraints,NFEs,Elapsed_Time]=WCA_Const(objective_function,constraints,LB,UB,nvars)

    
    disp(['Run: ',num2str(k),'   Fmin= ',num2str(Fmin),'  Summation Constraint Violations:  ',num2str(SUM_Constraints)]);
    
    F(k)=Fmin;
    N(k)=NFEs;
    
end

[Min_F index]=min(F)
Ave_F=mean(F)
Max_F=max(F)
SD_F=std(F)

[Min_NFEs indexx]=min(N)
Ave_NFEs=mean(N)
Max_NFEs=max(N)
SD_NFEs=std(N)
