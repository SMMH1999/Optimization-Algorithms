%_________________________________________________________________________
%  Light Spectrum Optimizer: A Physics-Inspired Metaheuristic, source code (Developed in MATLAB R2019a)
%
%  Programmed by Reda Mohamed & Dr.Mohamed abdel-basset
clear all
clc
% Definition of LSO'Parameters
popSize=25; % Number of search agents
Max_iter=50000; % Maximum number of function evaluations
RUN_NO=30; % Number of independent times
xc=1;
Fun_id=[1,2,3,4,5,6];
time=0*ones(1,12);
for i=1:23
  [lb,ub,dim,fobj]=Get_Functions_details(Fun_id(i));
  for j=1:RUN_NO
      tic;
     [Best_score,Best_pos,Convergence_curve]=LSO(popSize,Max_iter,ub,lb,dim,fobj);
     time(1)=time(1)+toc;
     tic;
     display(['The best fitness of LSO is: ', num2str(Best_score)]);
     [Best_score,Best_pos,Convergence_curve]=SSA(popSize,Max_iter,lb,ub,dim,fobj);
     time(2)=time(2)+toc;
     tic;
     display(['The best fitness of SSA is: ', num2str(Best_score)]);
     [Best_score,Best_pos,Convergence_curve]=GBO(popSize,Max_iter,lb,ub,dim,fobj);
     time(3)=time(3)+toc;
     tic;
     display(['The best fitness of GBO is: ', num2str(Best_score)]);
     [Best_score,Best_pos,Convergence_curve]=RUN(popSize,Max_iter,lb,ub,dim,fobj);
     time(4)=time(4)+toc;
     tic;
     display(['The best fitness of RUN is: ', num2str(Best_score)]);
    [Best_score,Best_pos,Convergence_curve]=WOA(popSize,Max_iter,lb,ub,dim,fobj);
    time(5)=time(5)+toc;
     tic;
    display(['The best fitness of WOA is: ', num2str(Best_score)]);
    [Best_score,Best_pos,Convergence_curve]=GTO(popSize,Max_iter,lb,ub,dim,fobj);
    time(6)=time(6)+toc;
     tic;
    display(['The best fitness of GTO is: ', num2str(Best_score)]);
    [Best_score,Best_pos,Convergence_curve]=AVOA(popSize,Max_iter,lb,ub,dim,fobj);
    time(7)=time(7)+toc;
     tic;
    display(['The best fitness of AVOA is: ', num2str(Best_score)]);
    [Best_score,Best_pos,Convergence_curve]=EO(popSize,Max_iter,ub,lb,dim,fobj);
    time(8)=time(8)+toc;
     tic;
    display(['The best fitness of EO is: ', num2str(Best_score)]);
   [Best_score,Best_pos,Convergence_curve]=GWO(popSize,Max_iter,lb,ub,dim,fobj);
   time(9)=time(9)+toc;
     tic;
   display(['The best fitness of GWO is: ', num2str(Best_score)]);
   [Best_score,Best_pos,Convergence_curve]=RSA(popSize,Max_iter,ub,lb,dim,fobj);
   time(10)=time(10)+toc;
     tic;
   display(['The best fitness of RSA is: ', num2str(Best_score)]);
   [Best_score,Best_pos,Convergence_curve]=SMA(popSize,Max_iter,lb,ub,dim,fobj);
   time(11)=time(11)+toc;
     tic;
   display(['The best fitness of SMA is: ', num2str(Best_score)]);
   [Best_score,Best_pos,Convergence_curve]=DE(popSize,Max_iter,lb,ub,dim,fobj,0.5,0.5);
   time(12)=time(12)+toc;
     tic;
   display(['The best fitness of DE is: ', num2str(Best_score)]);
   disp(sprintf("--------------------------------------"));
  end
  
end
time=time/(RUN_NO*size(Fun_id,2));
