%_________________________________________________________________________%
% Light Spectrum Optimizer (LSO) source codes demo 1.0               %
%                                                                         %
%  Developed in MATLAB R2019A                                      %
%                                                                         %
%  Author and programmer: Reda Mohamed (E-mail: redamoh@zu.edu.eg) & Mohamed Abdel-Basset (E-mail: mohamedbasset@ieee.org)                              %
%                                                                         %
%   Main paper: Abdel-Basset, M., Mohamed, R.                                    %
%               Light Spectrum Optimizer: A Novel Physics-Inspired Metaheuristic Optimization Algorithm,                         %
%               Mathematics 2022, 10(19), 3466,              %
%               DOI: https://doi.org/10.3390/math10193466   %
%                                                                         %

function [GBest_fitness,GBestRayColor,Conv_curve]=LSO(NoF_LightRays,Max_iter,ub,lb,dim,fobj)

%% INITIALIZATION STEP

%
red=1.3318; violet=1.3435;    % From assumption (2)

Conv_curve=zeros(1,Max_iter); % Convergence curve

it=1; % Loop counter

%% LSO's parameters
Ps=0.05; %% Probaility of first and second scattering stages
Pe=0.6;  %% Contolling parameter to exchange between the first and second scattering 
Ph=0.4;  %% Pobability of Hybridization between two various search boundary methods 
B=0.05;  %% Exploitation probability in the first scattering stage
% Generate initial population of White Rays
for i=1:NoF_LightRays,
  LightRays(i,:)=lb+(ub-lb).*rand(1,dim);
   % Calculate objective function for each search agent
  fitness(i)=fobj(LightRays(i,:));
end

% initialize Global & Personal best solution
[GBest_fitness,index]=min(fitness);
GBestRayColor=LightRays(index,:);    
NewWLightRays=LightRays;

%% Main loop

while it<=Max_iter
    for i=1:NoF_LightRays
       % COLORFUL DISPERSION OF LIGHT RAYS
        nA=LightRays(randi(NoF_LightRays),:);        
        nB= LightRays(i,:); 
        nC=GBestRayColor; 
        xbar=(sum(LightRays)/NoF_LightRays);
        norm_nA=nA/norm(nA);   % the normal vector of inner refraction  "equation (6)"
        norm_nB=nB/norm(nB);   % the normal vector of inner reflection  "equation (7)"
        norm_nC=nC/norm(nC);   % the normal vector of outer refraction  "equation (8)"
       
        Incid_norm=xbar/norm(xbar); % the normal vector of the incident light ray  "equation (11)"
        
        
        k=red+rand.*(violet-red);      % % Random Refractive Index "equation (15)"
        
        p=rand; 
        q=rand; 
        L1=(1./k).*(Incid_norm-(norm_nA.*dot(norm_nA,Incid_norm)))-(norm_nA.*(abs((1-(1./k.^2)+((1./k.^2).*dot(norm_nA,Incid_norm).^2)))).^(1/2)); % "equaton (12)"
        L2=L1-((2.*norm_nB).*dot(L1,norm_nB)); % "equation (13)" 
        L3=k.*(L2-(norm_nC.*dot(norm_nC,L2)))+norm_nC.*(abs(1-(k.^2)+(k.^2).*((dot(norm_nC,L2)).^2))).^(1/2); % "equation (14)" 
       
        a=rand*(1-it/Max_iter) ;    % "equation (20)"         
        ginv = gammaincinv(a,1); % compute the new ginv value
        GI=a*(1/rand)*ginv;   %"equation (19)"
        Epsln=a.*randn(1,dim);  %  "equation (18)" 
 
        if p<=q
            NewWLightRays(i,:)=LightRays(i,:)+GI.*Epsln.*rand(1,dim).*(L1-L3).*(LightRays(randi(NoF_LightRays),:)-LightRays(randi(NoF_LightRays),:));   % "equation (17)"  
        else
            NewWLightRays(i,:)=(LightRays(i,:))+GI.*Epsln.*rand(1,dim).*(L2-L3).*(LightRays(randi(NoF_LightRays),:)-LightRays(randi(NoF_LightRays),:));   % "equation (18)"
        end
        % % % check bound limitation  
        if rand<Ph
            U=NewWLightRays(i,:)>ub;
            L=NewWLightRays(i,:)<lb;
            NewWLightRays(i,:)=(NewWLightRays(i,:).*(~(U+L)))+ub.*U+lb.*L;
        else
            for j=1:size(LightRays,2)
               if  NewWLightRays(i,j)>ub(j)
                   NewWLightRays(i,j)=lb(j)+rand*(ub(j)-lb(j));
               elseif  NewWLightRays(i,j)<lb(j)
                   NewWLightRays(i,j)=lb(j)+rand*(ub(j)-lb(j));
               end
            end
         end
         % Calculate objective function for each search agent
         Fnew=fobj(NewWLightRays(i,:));
        % If fitness improves (better solutions found), update then
        if (Fnew<=fitness(i)),
             LightRays(i,:)=NewWLightRays(i,:);
             fitness(i)=Fnew;
        end
     %% update Global best solution
        if  Fnew<=GBest_fitness
            GBestRayColor=NewWLightRays(i,:);    % Update Global best solution
            GBest_fitness=Fnew;
        end
        [in1]=sort(fitness);
        Conv_curve(it)=GBest_fitness;
        it=it+1;
        if (it>Max_iter)
           break;
        end
% % %         Scattering stages
        F=abs((fitness(i)-GBest_fitness)/(GBest_fitness-(in1(NoF_LightRays)))); %  "equation (25)" 
        if F<rand || rand<Ps
            if rand<Pe
                  NewWLightRays(i,:)=(LightRays(i,:))+(rand)*(LightRays(randi(NoF_LightRays),:)-LightRays(randi(NoF_LightRays),:))+(rand<B).*rand(1,dim).*((GBestRayColor - LightRays(i,:))); %  "equation (21)" 
            else          
                  NewWLightRays(i,:)=(((2*cos(rand*180)).*(GBestRayColor.*LightRays(i,:))));   % "equation (22)"
            end
        else
            U=(rand(1,dim)>rand(1,dim));
            NewWLightRays(i,:)= U.*(LightRays(randi(NoF_LightRays),:)+abs(randn).*(LightRays(randi(NoF_LightRays),:)-LightRays(randi(NoF_LightRays),:)))+(1-U).*LightRays(i,:);  % "equation (24)"
        end 
        % % % check bound limitation  
        if rand<Ph
               U=NewWLightRays(i,:)>ub;
               L=NewWLightRays(i,:)<lb;
               NewWLightRays(i,:)=(NewWLightRays(i,:).*(~(U+L)))+ub.*U+lb.*L;
        else
            for j=1:size(LightRays,2)
            if  NewWLightRays(i,j)>ub(j)
                NewWLightRays(i,j)=lb(j)+rand*(ub(j)-lb(j));
            elseif  NewWLightRays(i,j)<lb(j)
                NewWLightRays(i,j)=lb(j)+rand*(ub(j)-lb(j));
            end
            end
         end
     % Calculate objective function for each search agent
     Fnew=fobj(NewWLightRays(i,:));
     % If fitness improves (better solutions found), update then
     if (Fnew<=fitness(i)),
          LightRays(i,:)=NewWLightRays(i,:);
          fitness(i)=Fnew;
      end
     %% update Global best solution
      if  Fnew<=GBest_fitness
          GBestRayColor=NewWLightRays(i,:);    % Update Global best solution
          GBest_fitness=Fnew;
      end
      Conv_curve(it)=GBest_fitness;
      it=it+1;
      if (it>Max_iter)
        break;
      end
    end  %% end i 
end %% End the optimization process
end %% 


