
%_________________________________________________________________________%
% A Novel Hybrid Salp Swarm Kepler Optimization Algorithm (SSAKOA) soruce codes version 1.0
% Created by Dr. Aykut Fatih GÜVEN (afatih.guven@yalova.edu.tr)
% Main paper: A novel hybrid Salp Swarm Kepler optimization for optimal sizing and energy management of renewable microgrids with EV integration
% Energy, 2025, 334:137696. 
% DOI: https://doi.org/10.1016/j.energy.2025.137696.
%_________________________________________________________________________%
% You can simply define your cost in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of generations
% N = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single number numbers

% Main script for SSAKOA
% Hybrid Salp Swarm Kepler Optimization Algorithm
clc;
clear;
close all;
% ----------- Parameters ------------
N = 30;                  % Number of search agents
Max_iteration = 500;     % Maximum number of iterations
Function_name = 'F1';    % Choose from F1 to F23 (case-sensitive)
disp(['Using test function: ', Function_name]);
% ----------- Get function details ------------
try
    [lb, ub, dim, fobj] = Get_Functions_details(Function_name);
catch ME
    error('Function not found in Get_Functions_details: %s', Function_name);
end

% ----------- Run SSAKOA algorithm ------------
[Fbest, FoodPosition, Convergence_curve] = SSAKOA(N, Max_iteration, lb, ub, dim, fobj);

% ----------- Display results ------------
disp('---------------------------------------------');
disp(['Best solution (position): ', mat2str(FoodPosition)]);
disp(['Best objective value found: ', num2str(Fbest)]);
disp(['Initial (worst) value: ', num2str(Convergence_curve(1))]);
disp(['Mean of all iterations: ', num2str(mean(Convergence_curve))]);
disp('---------------------------------------------');
% ----------- Plot convergence (log scale) ------------
figure('Color', [1 1 1]);
semilogy(Convergence_curve, '--', 'LineWidth', 2, 'Color', [0 0.447 0.741]);
xlabel('Iteration');
ylabel('Best fitness so far');
title(['Convergence Curve (log scale) - ', Function_name]);
grid on;
box on;
legend('SSAKOA');
% ----------- Plot convergence (linear scale) ------------
figure('Color', [1 1 1]);
plot(Convergence_curve, '-', 'LineWidth', 2, 'Color', [0.85 0.325 0.098]);
xlabel('Iteration');
ylabel('Best fitness so far');
title(['Convergence Curve (linear scale) - ', Function_name]);
grid on;
box on;
legend('SSAKOA');
