clc; clear; close all;

%% Problem Definition
func = 'rastrigin'; % Choose: 'sphere', 'rastrigin', 'rosenbrock'
dim = 10;          % Number of decision variables
lb = -5;           % Lower bound
ub = 5;            % Upper bound
popSize = 30;      % Population size
maxIter = 1000;    % Maximum iterations

% Objective Function
switch func
    case 'sphere'
        fobj = @(x) sum(x.^2);
    case 'rastrigin'
        fobj = @(x) 10*length(x) + sum(x.^2 - 10*cos(2*pi*x));
    case 'rosenbrock'
        fobj = @(x) sum(100*(x(2:end) - x(1:end-1).^2).^2 + (1 - x(1:end-1)).^2);
    otherwise
        error('Invalid function name');
end

%% Initialization
pop = lb + (ub - lb) * rand(popSize, dim); % Initial random population
fitness = arrayfun(@(i) fobj(pop(i, :)), 1:popSize)';
[bestFitness, bestIdx] = min(fitness);
bestSolution = pop(bestIdx, :);
convergence = zeros(maxIter,1); % Store best fitness over iterations

%% Temperature Initialization
initialTemp = 100;   % Initial temperature
coolingRate = 0.99;  % Cooling rate
minTemp = 1e-3;      % Minimum temperature
adaptiveCooling = 0.95; % Adaptive cooling factor

%% Main Optimization Loop (Hot Box Optimization)
for iter = 1:maxIter
    temp = initialTemp * (coolingRate ^ iter); % Temperature reduction
    if temp < minTemp
        break;
    end
    
    % Adaptive Cooling Adjustment
    if mod(iter, 100) == 0
        coolingRate = coolingRate * adaptiveCooling;
    end
    
    for i = 1:popSize
        % Generate New Solution by Perturbing Current One
        newSol = pop(i, :) + (rand(1, dim) - 0.5) * temp;
        newSol = max(min(newSol, ub), lb); % Boundary constraints
        
        % Evaluate New Solution
        newFitness = fobj(newSol);
        
        % Acceptance Probability: Accept new solution if better or based on probability
        if newFitness < fitness(i) || rand < exp(-(newFitness - fitness(i)) / temp)
            pop(i, :) = newSol;
            fitness(i) = newFitness;
        end
    end
    
    % Hybrid Local Search (Gradient Descent Inspired)
    if mod(iter, 200) == 0 % Every 200 iterations
        gradStep = 0.01; % Small step size for refinement
        bestSolution = bestSolution - gradStep * (2 * bestSolution);
        bestSolution = max(min(bestSolution, ub), lb);
        bestFitness = fobj(bestSolution);
    end
    
    % Update Best Solution
    [currBestFitness, bestIdx] = min(fitness);
    if currBestFitness < bestFitness
        bestFitness = currBestFitness;
        bestSolution = pop(bestIdx, :);
    end
    
    % Store Convergence Data
    convergence(iter) = bestFitness;
    
    % Display Progress
    if mod(iter, 100) == 0 || iter == 1
        disp(['Iteration ' num2str(iter) ': Best Fitness = ' num2str(bestFitness)]);
    end
end

%% Display Results
disp('Optimal Solution Found:');
disp(bestSolution);
disp(['Optimal Fitness: ' num2str(bestFitness)]);

%% Plot Convergence Curve
figure;
plot(1:maxIter, convergence, 'b-', 'LineWidth', 2);
xlabel('Iterations');
ylabel('Best Fitness');
title('Convergence Curve of Hot Box Optimization');
grid on;