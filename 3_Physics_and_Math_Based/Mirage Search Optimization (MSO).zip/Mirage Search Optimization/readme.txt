Mirage search optimization (MSO)
 
February 4, 2025

email: zhaoshijie@lntu.edu.cn 
       lntuhjh@126.com

The files in this zip archive are MATLAB m-files that can be used to study Mirage search optimization algorithm.

MSO is the method that we invented and wrote about in the following paper:
Jiahao He, Shijie Zhao, Jiayi Ding, Yiming Wang, Mirage search optimization.

The MATLAB files and their descriptions are as follows:
Get_Functions_Details.m
This is the benchmark functions discussed in the paper. You can use it as template to write your own function if you are interested in testing or optimizing some other functions. 
MSO.m
This is the core code of the SHO algorithm.
initialization.m
This contains various initialization settings for the optimization methods. You can edit this file to change the population size, the generation count limit, the problem dimension, the maximum Function Evaluations (FEs), and the percentage of population of any of the optimization methods that you want to run.
I hope that this software is as interesting and useful to you as is to me. Feel free to contact me with any comments or questions.



