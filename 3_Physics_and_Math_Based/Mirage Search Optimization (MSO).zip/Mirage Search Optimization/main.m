%__________________________________________________________________
%  Mirage Search Optimization (MSO)
%  Developed in MATLAB R2022a
%
%  programmer: Shijie Zhao and Jiahao He  
%  E-mail: zhaoshijie@lntu.edu.cn
%          lntuhjh@126.com
%  The code is based on the following papers.
%  Jiahao He, Shijie Zhao, Jiayi Ding, Yiming Wang
%  Mirage search optimization: Application to path planning and engineering design problems
%  Advances in Engineering Software
%
%__________________________________________________________________
clc
clear
close all

SearchAgents_no = 30; % Number of search agents
Max_iter        = 1000; % Maximum numbef of iterations
Fname           = 'F1' ;%Fname: F1-F30. 

[lb, ub, dim, fobj] = Get_Functions_Details(Fname);

tic
[gbests, gbest, cg_curve] = MSO(fobj, dim, lb, ub, SearchAgents_no, Max_iter);
time=toc;

semilogy(1:Max_iter,cg_curve,'color','r','linewidth',2.5);
title('Convergence curve');
xlabel('Iteration');
ylabel('Best score obtained so far')
display(['The running time is:', num2str(time)]);
display(['The best position is: ', num2str(gbests)]);
display(['The best fitness is: ', num2str(gbest)]);