function y = objective(x)

y = 1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14.0+x(2));
  
return