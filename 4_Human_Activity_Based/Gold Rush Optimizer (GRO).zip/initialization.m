%  Gold Rush Optimizer (GRO)  
%
%  Source code version 1.0                                                                      
%                                                                                                     
%  Developed in MATLAB R2013b(v 8.2)                                                                   
%                                                                                                     
%  Author and programmer: Kamran Zolfi                                                          
%                                                                                                     
%  e-Mail: zolfi@iauln.ac.ir   
%          kamran.zolfi@gmail.com    
%  main article:
%           Gold Rush optimizer. A new population-based metaheuristic algorithm
%           DOI: 10.37190/ord230108
%           journal: Operations Research and Decisions
%           Vol. 33, No. 1 (2023)  
%%
% This function initialize the first population of search agents
function Positions=initialization(SearchAgents_no,dim,lb,ub)

% generate random position between lb and ub
delta = repmat(ub-lb,SearchAgents_no,1);
lb = repmat(lb, SearchAgents_no,1);
Positions = rand(SearchAgents_no,dim).* delta + lb;
end
