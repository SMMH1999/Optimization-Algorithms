%  Gold Rush Optimizer (GRO)  
%
%  Source code version 1.0                                                                      
%                                                                                                     
%  Developed in MATLAB R2013b(v 8.2)                                                                   
%                                                                                                     
%  Author and programmer: Kamran Zolfi                                                          
%                                                                                                     
%  e-Mail: zolfi@iauln.ac.ir   
%          kamran.zolfi@gmail.com    
%  main article:
%           Gold Rush optimizer. A new population-based metaheuristic algorithm
%           DOI: 10.37190/ord230108  10.37190/ord230108
%           journal: Operations Research and Decisions
%           Vol. 33, No. 1 (2023)
%%

clc;
SearchAgents_no=30;                                 % Number of search agents
TestCase ='F1';                                     % Name of the test function 
Max_iteration=500;                                  % Maximum numbef of iterations
[lb,ub,dim,fobj]=Get_Functions_details(TestCase);    
[Best_score,Best_pos,cg_curve]=GRO(dim,SearchAgents_no,Max_iteration,lb,ub,fobj);
 Best_score

