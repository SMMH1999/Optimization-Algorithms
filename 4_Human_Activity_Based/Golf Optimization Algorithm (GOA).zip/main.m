


%%
% Golf Optimization Algorithm: A New Game-Based Metaheu-ristic Algorithm and its Application to Energy Commitment Problem Considering Resilience
%
% Zeinab Montazeri1, Taher Niknam1,*, Jamshid Aghaei1, Om Parkash Malik2, Mohammad Dehghani1, and Gaurav Dhiman3
%1	Department of Electrical and Electronics Engineering, Shiraz University of Technology, Shiraz 7155713876, Iran; z.montazeri@sutech.ac.ir (Z.M.); niknam@sutech.ac.ir (T.N.); Aghaei@sutech.ac.ir (J.A); M.Dehghani@sutech.ac.ir (M.D) 
%2	Department of Electrical and Software Engineering, University of Calgary, Calgary, AB T2N 1N4, Canada; maliko@ucalgary.ca (O.P.M.)
%3	Department of Computer Science, Government Bikram College of Commerce, Patiala, India; gdhiman0001@gmail.com (G.D.)
%*	Correspondence: niknam@sutech.ac.ir; Tel.: +989171876173

%%
% GOA
%%
% " Optimizer"
%%
clc
clear
close all
%%
Fun_name='F1';
SearchAgents=30;
Max_iterations=1000;
%%

[lowerbound,upperbound,dimension,fitness]=fun_info(Fun_name);
[Best_score,Best_pos,GOA_curve]=GOA(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness);

%%

display(['The best optimal value of the objective funciton found by GOA is : ', num2str(Best_score)]);

