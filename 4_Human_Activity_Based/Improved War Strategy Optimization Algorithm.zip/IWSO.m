% Improved War Strategy Optimization with A Novel Random Opposition-Based Learning

% Please cite:
% Aydilek, İ.B.; Uslu, A.; Kına, C. Improved War Strategy Optimization with Extreme Learning Machine for Health Data Classification. Appl. Sci. 2025, 15, 5435. https://doi.org/10.3390/app15105435

% usage -> [King_fit, King,Convergence_curve] =IWSO(populationSize,Max_iteration,lb,ub,dim,fobj)

function [King_fit,King,Convergence_curve]=IWSO(Soldiers_no,Max_iter,lb,ub,dim,fobj)

King=zeros(1,dim);
King_fit=inf;
Positions=initialization(Soldiers_no,dim,ub,lb);
pop_size=size(Positions,1);Convergence_curve=zeros(1,Max_iter);

Positions_new=zeros(size(Positions));
fitness_old=inf*ones(1,pop_size);
fitness_new=inf*ones(1,pop_size);
l=1;
W1=2*ones(1,pop_size);
Wg=zeros(1,pop_size);

% Main loop
R=0.1; 
for  j=1:size(Positions,1)
         fitness=fobj(Positions(j,:));
         fitness_old(j)=fitness;

        if fitness<King_fit
            King_fit=fitness;
            King=Positions(j,:);
        end
        
end
 
while l<Max_iter
[~,tindex]=sort(fitness_old);
Co=Positions(tindex(2),:);
   com=randperm(pop_size);  
    for i=1:pop_size
        RR=rand;
        if RR<R

            D_V(i,:)=2*RR*(King-Positions(com(i),:))+1*W1(i)*rand*(Co-Positions(i,:)); 
        else
            D_V(i,:)=2*RR*(Co-King)+1*rand*(W1(i)*King-Positions(i,:)); 
        end
            Positions_new(i,:)=Positions(i,:)+D_V(i,:);
            Flag4ub=Positions_new(i,:)>ub;
            Flag4lb=Positions_new(i,:)<lb;
            Positions_new(i,:)=(Positions_new(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;  
            fitness=fobj(Positions_new(i,:));
            fitness_new(i) = fitness;
        %random opposition-based learning phase begin
        xbar_OBL= ub + lb - Positions_new(i,:);
        x_proposed_ROBL= (rand*(xbar_OBL-Positions_new(i,:)))+Positions_new(i,:);
        x_proposed_ROBL(x_proposed_ROBL>ub)=ub;
        x_proposed_ROBL(x_proposed_ROBL<lb)=lb;
    
        fitness_temp=fobj(x_proposed_ROBL);
        if fitness_temp<fitness
            Positions_new(i,:)=x_proposed_ROBL;
            fitness_new(i)=fitness_temp;
            fitness=fitness_new(i);
        end
        %random opposition-based learning phase end
        if fitness<King_fit
            King_fit=fitness;
            King=Positions_new(i,:);
        end
        if fitness<fitness_old(i)
            Positions(i,:)=Positions_new(i,:);
            fitness_old(i)=fitness;
            Wg(i)=Wg(i)+1;
            W1(i)=1*W1(i)*(1-Wg(i)/Max_iter)^2;
        end
    end
    if l<1000
        [~,tindex1]=max(fitness_old);
        Positions(tindex1,:)=lb+rand*(ub-lb);
    end
    l=l+1;    
    Convergence_curve(l)=King_fit;
end



