% Improved War Strategy Optimization with A Novel Random Opposition-Based Learning

% Please cite:
% Aydilek, İ.B.; Uslu, A.; Kına, C. Improved War Strategy Optimization with Extreme Learning Machine for Health Data Classification. Appl. Sci. 2025, 15, 5435. https://doi.org/10.3390/app15105435

% usage -> [King_fit, King,Convergence_curve] =IWSO(populationSize,Max_iteration,lb,ub,dim,fobj)

clear
clc
fEvals = 30000;    
populationSize=30; % Number of search agents
Max_iteration = 1000;
runs = 10;

for fn = 1:25 
   Function_name=strcat('F',num2str(fn)); % Name of the Uni test function 
   [lb,ub,dim,fobj]=Get_Functions_Details_Uni(Function_name); % for Ulti
    
%    Function_name=strcat('MF',num2str(fn)); % Name of the Multi test function 
%    [lb,ub,dim,fobj]=Get_Functions_Details_Multi(Function_name); % for Multi

    % Calling algorithm
    Best_score_T = zeros(1,runs);
    run_times_T=zeros(1,runs);
    for run=1:runs
        rng('shuffle');
        tic
        [King_fit, King,Convergence_curve]  =IWSO(populationSize,Max_iteration,lb,ub,dim,fobj);
        run_times_T(1,run)=toc;
        Best_score_T(1,run) = King_fit;
        
%       Best_score_0
    end

    %Finding statistics
    Best_score_Best = min(Best_score_T);
    Best_score_Worst = max(Best_score_T);
    Best_score_Median = median(Best_score_T,2);
    Best_Score_Mean = mean(Best_score_T,2);
    Best_Score_std = std(Best_score_T);
    avgRuntime=mean(run_times_T);
    %Printing results
    %display(['Fn = ', num2str(fn)]);
    %display(['Median, Mean, and Std. are as: ',  ...
    %num2str(Best_score_Median),'  ', num2str(Best_Score_Mean),'  ', num2str(Best_Score_std)]);
    Best_Score_Mean_list(fn,:)=[fn,Best_Score_Mean,Best_Score_std,Best_score_Best,Best_score_Worst,Best_score_Median,avgRuntime];
    clc;
    disp('FuncNO, Mean, Std., Best, Worst, Median, avg.Runtime are as:');
    disp(Best_Score_Mean_list);
end
