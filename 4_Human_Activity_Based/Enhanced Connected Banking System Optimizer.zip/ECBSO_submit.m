
function [Best_fit,Best_X,Conv_Curve]=ECBSO_submit(N,tmax,lb,ub,Dim,fobj)

Best_X=zeros(1,Dim);
Best_fit=inf;

Conv_Curve=zeros(1,tmax);

fitness=inf(N,1);


X=initializationCBSO(N,Dim,ub,lb);

LB=repmat(ones(1,Dim).*lb,N,1);
UB=repmat(ones(1,Dim).*ub,N,1);

t=0;


Cov_Store_Pos=[];
Cov_Store_Fit=[];

lb=lb.*ones(1,Dim);
ub=ub.*ones(1,Dim);
%% GLS initialization
lu=[lb;ub];                         %problem boundary information

A=30;
C=0;
Cmax=3000;
St=zeros(Cmax,Dim);
B=200./(ub-lb);
%% GLS initialization ended


V = 1;  a1 = 2;  a2 = 1;  GP = 0.5; % EO parameters
Ceq2 = zeros(1,Dim);  Ceq2_fit = inf;
Ceq3 = zeros(1,Dim);  Ceq3_fit = inf;
Ceq4 = zeros(1,Dim);  Ceq4_fit = inf;


while t<tmax

    for i=1:size(X,1)

        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;

        fitness(i,1)=fobj(X(i,:));

        if fitness(i,1)<Best_fit
            Best_fit=fitness(i,1);
            Best_X=X(i,:);
        end




      
        C=C+1;
        St(C,:)=X(i,:);
        if C>=Cmax
            V0=std(St,0,1).*B;
            C=0;
          
            [Best_X,Best_fit,X,fitness]=GLS_submit(Best_X,Best_fit,X,fitness,lu,V0,A,fobj,i);

        end




    end



    if t==0
        fit_old=fitness;    X_old=X;
    end

    Inx=(fit_old<fitness);
    Indx=repmat(Inx,1,Dim);
    X=Indx.*X_old+~Indx.*X;
    fitness=Inx.*fit_old+~Inx.*fitness;

    fit_old=fitness;    X_old=X;


    Fit=fitness';
    [~, index]   = sort(fitness);




   for i = 1:N 
        if fitness(i,1)<Best_fit
            Best_fit= fitness(i,1);  Best_X = X(i,:);
        elseif fitness(i,1)>Best_fit && fitness(i,1)<Ceq2_fit
            Ceq2_fit = fitness(i,1);  Ceq2 = X(i,:);
        elseif fitness(i,1)>Best_fit&& fitness(i,1)>Ceq2_fit && fitness(i,1)<Ceq3_fit
            Ceq3_fit = fitness(i,1);  Ceq3 = X(i,:);
        elseif fitness(i,1)>Best_fit&& fitness(i,1)>Ceq2_fit && fitness(i,1)>Ceq3_fit && fitness(i,1)<Ceq4_fit
            Ceq4_fit =fitness(i,1);  Ceq4 = X(i,:);
        end
 
   end 
   Ceq_ave = (Best_X + Ceq2 + Ceq3 + Ceq4)/4; % Average candidate solution
    C_pool = [Best_X; Ceq2; Ceq3; Ceq4; Ceq_ave]; % Equilibrium pool
    % Update EO parameters
    tt = (1-t/tmax)^(a2*t/tmax);
    lambda = rand(N,Dim);
    r1 = rand(N,1);
    r2 = rand(N,1);
    rn = randi(size(C_pool,1),N,1);
    rr = rand(N,Dim);
    [~, index]  = sort(fitness,'descend');  
     iI = 1:N;
    rank(index(iI)) = (N-iI+1)/N ; % Eq.(13): rank the population according to their fitness




    Elite=repmat(Best_X,N,1);
    CF=rand*(1-t/tmax);

    Levy_step=levy(N,Dim,1.5);
    Brown_step=randn(N,Dim);

    for i=1:size(X,1)
                if rank(i)>0.5
            Ceq = C_pool(rn(i,1),:); % Select a solution randomly from the equilibrium pool
            F = a1*sign(rr(i,:)-0.5).*(exp(-lambda(i,:).*tt)-1);
            GCP = 0.5*r1(i,1)*ones(1,Dim)*(r2(i,1)>=GP);
            G = (GCP.*(Ceq-lambda(i,:).*X(i,:))).*F;
            X(i,:) = Ceq+(X(i,:)-Ceq).*F+(G./lambda(i,:)*V).*(1-F);
        else
        SEL1=randi([1 i],1);
        SEL2=randi([1 i],1);
       if t<0.4*tmax
       temp_pos = mvnrnd(mu,C_matrix,1);
       end
        for j=1:size(X,2)
            R=rand();

            if t<0.2*tmax

                X(i,j)=temp_pos(j);


            elseif t>=0.2*tmax && t<=0.4*tmax

                if i>size(X,1)/2

                    X(i,j)=Elite(i,j)+CF*(Brown_step(i,j)*(rand*Elite(i,j)-X(SEL1,j)));
                else

                    X(i,j)=temp_pos(j);
                end


            else


                X(i,j)=Elite(i,j)+CF*(Levy_step(i,j)*(Levy_step(i,j)*X(SEL1,j)-X(SEL2,j)));

            end
        end
    end
    end


    for i=1:size(X,1)

        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;

         fitness(i,1)=fobj(X(i,:));

        if  fitness(i,1)<Best_fit
            Best_fit= fitness(i,1);
            Best_X=X(i,:);
        end
             

      
        C=C+1;
        St(C,:)=X(i,:);
        if C>=Cmax
            V0=std(St,0,1).*B;
            C=0;
        
            [Best_X,Best_fit,X,fitness]=GLS_submit(Best_X,Best_fit,X,fitness,lu,V0,A,fobj,i);

        end
    end





  




    if t==0
        fit_old=fitness;    X_old=X;
    end

    Inx=(fit_old<fitness);
    Indx=repmat(Inx,1,Dim);
    X=Indx.*X_old+~Indx.*X;
    fitness=Inx.*fit_old+~Inx.*fitness;

    fit_old=fitness;    X_old=X;



    if rand()<0.2

        X=X+rand*(CF*LB+rand(N,Dim).*(UB-LB));


    else
        r=rand();  XS=size(X,1);
        X=X+rand*rand*(X(randperm(XS),:)-X(randperm(XS),:));
    end





    t=t+1;
 Conv_Curve(t)=Best_fit;
end



    function Positions=initializationCBSO(n_PoP,n_dim,ub,lb)

        B_S= size(ub,2);

        if B_S==1
            Positions=rand(n_PoP,n_dim).*(ub-lb)+lb;
        end


        if B_S>1
            for i=1:n_dim
                ub_i=ub(i);
                lb_i=lb(i);
                Positions(:,i)=rand(n_PoP,1).*(ub_i-lb_i)+lb_i;
            end
        end
    


    function [z] = levy(n,m,beta)

        num = gamma(1+beta)*sin(pi*beta/2);

        den = gamma((1+beta)/2)*beta*2^((beta-1)/2);

        sigma_u = (num/den)^(1/beta);

        u = random('Normal',0,sigma_u,n,m);

        v = random('Normal',0,1,n,m);

        z =u./(abs(v).^(1/beta));


    

