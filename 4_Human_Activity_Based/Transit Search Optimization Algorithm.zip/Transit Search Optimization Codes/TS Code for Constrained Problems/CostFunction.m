function [Vmin,Vmax,nV,Function] = CostFunction(F)
 
switch F
    case 'G1'
        Function = @G1;
        Vmin=[0 0 0 0 0 0 0 0 0 0 0 0 0];        % Lower bounds of variables
        Vmax=[1 1 1 1 1 1 1 1 1 100 100 100 1];  % Upper bounds of vAriables
        nV=13;                                   % Number of variables

        % F_min = -15 at X(1,1,...,1,3,3,3,1)    % Goal
end
end


%% Function
% Benchmark Function Name: G01 
function y = G1(x)
x1 = x(1:4); x2 = x(5:13);
y = 5*sum(x1)-5*sum(x1.*x1)-sum(x2);
end