
function[Fitness]=Penalty(P0,ConstraintFunction,CostFunction)

%% Step 1: Evaluate solutions infeasibility
fname = fieldnames(P0);
P0.(fname{2}) = CostFunction(P0.(fname{1}));  % Determination of the objective value for P0
Const_P = (ConstraintFunction(P0.(fname{1})))';
n_const = length(Const_P);    % Number of constraints
Constraints_Values = zeros(1,n_const);

Constraints_Values(1,:) = (ConstraintFunction(P0.(fname{1})))';
for j = 1:n_const
    if Constraints_Values(1,j) < 0
        Constraints_Values(1,j) = 0;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%% PENALTY %%%%%%%%%%%%%%%%%
SUM = sum(Constraints_Values);

%% Step 2: Calculate the Fitness
S=0;
for j=1:n_const
    S = S+ (Constraints_Values(1,j))^2;
end

if SUM ~=0
    Fitness = P0.(fname{2}) + (10^20)*S;
else
    Fitness = P0.(fname{2});
end

end