% Define the Sphere function
sphere_func = @(x) sum(x.^2);

% Define problem dimensionality and search space bounds
dim = 10;
lower_bound = -5 * ones(1, dim);
upper_bound = 5 * ones(1, dim);

% Define algorithm parameters
max_iter = 100;
swarm_size = 50;
pbest_rate = 0.8;
gbest_rate = 0.8;
alpha = 0.5;

% Run the CSO algorithm
[best_solution, best_fitness] = cso(sphere_func, dim, lower_bound, upper_bound, max_iter, swarm_size, pbest_rate, gbest_rate, alpha);

% Display results
disp(['Best solution found: ', num2str(best_solution)]);
disp(['Best fitness found: ', num2str(best_fitness)]);
