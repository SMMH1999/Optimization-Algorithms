function [best_solution, best_fitness] = cso(obj_func, dim, lower_bound, upper_bound, max_iter, swarm_size, pbest_rate, gbest_rate, alpha)
    % Initialize swarm
    swarm = lower_bound + (upper_bound - lower_bound) .* rand(swarm_size, dim);
    velocity = zeros(swarm_size, dim);
    pbest = swarm;
    
    % Evaluate initial swarm
    fitness = zeros(swarm_size, 1);
    for i = 1:swarm_size
        fitness(i) = obj_func(swarm(i, :));
    end
    
    % Find initial global best
    [~, gbest_index] = min(fitness);
    gbest = swarm(gbest_index, :);
    
    % Main loop
    for iter = 1:max_iter
        % Update swarm's velocity
        for i = 1:swarm_size
            if rand < pbest_rate
                velocity(i, :) = velocity(i, :) + alpha * (pbest(i, :) - swarm(i, :));
            end
            if rand < gbest_rate
                velocity(i, :) = velocity(i, :) + alpha * (gbest - swarm(i, :));
            end
        end
        
        % Update swarm's position
        swarm = swarm + velocity;
        
        % Ensure particles stay within bounds
        swarm = max(swarm, lower_bound);
        swarm = min(swarm, upper_bound);
        
        % Evaluate new swarm
        for i = 1:swarm_size
            fitness(i) = obj_func(swarm(i, :));
        end
        
        % Update personal best
        for i = 1:swarm_size
            if fitness(i) < obj_func(pbest(i, :))
                pbest(i, :) = swarm(i, :);
            end
        end
        
        % Update global best
        [~, gbest_index] = min(fitness);
        if fitness(gbest_index) < obj_func(gbest)
            gbest = swarm(gbest_index, :);
        end
    end
    
    best_solution = gbest;
    best_fitness = obj_func(gbest);
end
