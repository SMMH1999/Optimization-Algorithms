function z=CostFunction(x)

% Sphere Function
z=sum(x.^2);