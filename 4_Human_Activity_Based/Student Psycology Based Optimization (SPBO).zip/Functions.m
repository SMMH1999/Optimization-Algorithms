


%  Student psychology based optimization (SPBO)algorithm 
%
%  Source codes demo version 1.0                                                                      
%                                                                                                     
%  Developed in MATLAB R2017b                                                                  
%                                                                                                     
%  Author and programmer: Bikash Das, V. Mukherjee, D. Das                                                         
%                                                                                                     
%         e-Mail: bcazdas@gmail.com, vivek_agamani@yahoo.com, ddas@ee.iitkgp.ernet.in                                               
%                                                                                                                                                             
%                                                                                                     
%  Main paper:                                                                                        
%  Bikash Das, V Mukherjee, Debapriya Das, Student psychology based optimization algorithm: A new population based
%   optimization algorithm for solving optimization problems, Advances in Engineering Software, 146 (2020) 102804.
%_______________________________________________________________________________________________
% You can simply define your objective function in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @Objective function
% variable = number of your variables
% Max_iteration = maximum number of iterations
% student = number of search agents
% mini=[mini1,mini2,...,minin] where mini is the lower bound of variable n
% maxi=[maxi1,maxi2,...,maxin] where maxi is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define mini and maxi as two single numbers

% To run SPBO: [Best_fitness,Best_student,Convergence_curve]=SPBO(student,Max_iteration,mini,maxi,variable,fobj)
%______________________________________________________________________________________________




function [mini,maxi,variable,fobj] = Functions(F)


switch F
    case 'F1'
        fobj = @F1;
        mini=-5.12;
        maxi=5.12;
        variable=10;
        
    case 'F2'
        fobj = @F2;
        mini=-10;
        maxi=10;
        variable=10;
        
    case 'F3'
        fobj = @F3;
        mini=-100;
        maxi=100;
        variable=10;
        
    case 'F4'
        fobj = @F4;
        mini=-5.12;
        maxi=5.12;
        variable=10;
        
    case 'F5'
        fobj = @F5;
        mini=-1.28;
        maxi=1.28;
        variable=10;
        
              
end

end

% Step
% F1

function o = F1(x)
o=sum(((x+.5)).^2);
end

% Sum Square
% F2

function o = F2(x)
variable=size(x,2);
o=sum([1:variable].*(x.^2));
end

%   Sphere
% F3

function o = F3(x)
o=sum((x).^2);
end

% Rastrigin
% F4

function o = F4(x)
variable=size(x,2);
o=sum(x.^2-10*cos(2*pi.*x))+10*variable;
end

% Quartic
% F5

function o = F5(x)
variable=size(x,2);
o=sum([1:variable].*(x.^4));
end

