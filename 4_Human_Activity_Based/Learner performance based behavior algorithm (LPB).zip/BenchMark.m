function cost=BenchMark(x)
global count;
count=count+1;
Num_of_Dim=numel(x);
Fx=0;

%% ******************TF12 dim 10********************************************* [-50 50]
dim=size(x,2);
Fx=(pi/dim)*(10*((sin(pi*(1+(x(1)+1)/4)))^2)+sum((((x(1:dim-1)+1)./4).^2).*...
    (1+10.*((sin(pi.*(1+(x(2:dim)+1)./4)))).^2))+((x(dim)+1)/4)^2)+sum(Ufun(x,10,100,4));

%% ******************UFUN*********************************************
    function Fx=Ufun(x,a,k,m)
        Fx=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
    end
%% ******************Cost Value*********************************************
cost=Fx;
end