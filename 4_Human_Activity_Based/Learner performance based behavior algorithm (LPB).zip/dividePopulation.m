% Author Chnoor M. Rahman

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003


function [fPop, wPop, gPop, pPop] = dividePopulation(pop, divProbability)
nPop = length(pop);

% randomly select sr individuals from pop
sr = floor(nPop * divProbability);
r=randsample(nPop,sr);
rPop = pop(r);

% sort the population according to the best fitness (Cost)
rCosts=[rPop.Cost];
[~, SortOrder]=sort(rCosts);
sortedrPop  = rPop(SortOrder);

% Choose a group of the best population from the randomly chosen population
% firstPopulation
sizeOf1stGroup=floor(sr*divProbability);
for i = 1:sizeOf1stGroup
    bSortedrPop(i, :) = sortedrPop(i, :);
end
fPop = bSortedrPop;
worstOf1stGroup = sortedrPop(length(sortedrPop),:);

bestIndiv = sortedrPop(1,:);

% create a group of better population by removing the individuals that has
% smaller fitness than the worstOf1stGroup from pop
index = 1;
wIndex = 1;
worstPop.Position = [];
worstPop.Cost = [];
betterPop.Position = [];
betterPop.Cost = [];
for i=1:numel(pop)
    if(pop(i,:).Cost < worstOf1stGroup.Cost)
        betterPop(index,:) = pop(i,:);
        index = index + 1;
    else
        if(pop(i,:).Cost >= worstOf1stGroup.Cost)
            worstPop(wIndex,:) = pop(i,:);
            wIndex = wIndex + 1;
        end
    end
end
wPop = worstPop;

% create goodPopulation by selecting the individuals from better population
% that have a fitness smaller than or equal to the bestIndiv in the firstPopulation
pIndex = 1;
gIndex = 1;
perfectPop.Position = [];
perfectPop.Cost = [];

goodPop.Position = [];
goodPop.Cost = [];
for i=1:numel(betterPop)
    % create perfectPopulation
    if(betterPop(i,:).Cost < bestIndiv.Cost)
        perfectPop(pIndex,:) = betterPop(i,:);
        pIndex = pIndex + 1;
    else
        if(betterPop(i,:).Cost >= bestIndiv.Cost)
            goodPop(gIndex,:) = betterPop(i,:);
            gIndex = gIndex + 1;
        end
    end
end
pPop = perfectPop;
gPop = goodPop;

end