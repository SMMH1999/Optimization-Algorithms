% Author Chnoor M. Rahman

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003

function [child1, child2] = onePointCrossover(parent1, parent2)
% do a straight copy of the parent "genes" to the children
child1 = parent1;
child2 = parent2;

% define the crossover point randomly
[r c] = size(parent1);
CrossoverIndex = randi(c);
% now copy over the data from the other parent that is "crossed over" with the first
% parent
child1 = [parent1(1:CrossoverIndex) parent2(CrossoverIndex+1:end)];
child2 = [parent2(1:CrossoverIndex) parent1(CrossoverIndex+1:end)];
end