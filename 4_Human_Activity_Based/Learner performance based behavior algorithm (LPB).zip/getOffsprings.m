% Author Chnoor M. Rahman

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003

function [parent1P, parent2P, child1P, child2P, parent1C, parent2C] = getOffsprings(parent1, parent2, finCount, gamma, VarMin, VarMax)
parent1P = parent1(finCount).Position;
parent2P = parent2(finCount).Position;

% Apply Crossover to the chosen parents
[child1P, child2P] = Crossover(parent1P,parent2P,gamma,VarMin,VarMax);

% fitness of Parents
parent1C = parent1(finCount).Cost;
parent2C = parent2(finCount).Cost;

end