% Author Chnoor M. Rahman

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003

function i1 = parentSelection(fPop, fPopindex)
% Check to know whether the parent that has been selected is a member in
% fPopndex or not, to make sure that we dont have repetitve parents
i1 = randi([1 numel(fPop)]);
while (ismember(i1, fPopindex))
    i1 = randi([1 numel(fPop(:,1))]);
end
end