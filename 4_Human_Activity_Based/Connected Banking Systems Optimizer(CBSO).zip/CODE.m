clear all;
clc;

n_PoP=150;
M_Iter=1000; 
n_dim=10;
lb=-100;
ub=100;

Obj_Func=@(x)sphere(x);
Best_X=zeros(1,n_dim);
Best_fit=inf; 

Conv_Curve=zeros(1,M_Iter);

fit_val=inf(n_PoP,1);


X=initialization(n_PoP,n_dim,ub,lb);
  
XL=repmat(ones(1,n_dim).*lb,n_PoP,1);
XU=repmat(ones(1,n_dim).*ub,n_PoP,1);
         

Iter=0;

while Iter<M_Iter    

 for i=1:size(X,1)  
        
    Flag4ub=X(i,:)>ub;
    Flag4lb=X(i,:)<lb;    
    X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;                    
        
    fit_val(i,1)=Obj_Func(X(i,:));
                     
     if fit_val(i,1)<Best_fit 
       Best_fit=fit_val(i,1); 
       Best_X=X(i,:);
     end          
 end
     
   
    
 if Iter==0
   fit_old=fit_val;    X_old=X;
 end
     
  Inx=(fit_old<fit_val);
  Indx=repmat(Inx,1,n_dim);
  X=Indx.*X_old+~Indx.*X;
  fit_val=Inx.*fit_old+~Inx.*fit_val;
        
  fit_old=fit_val;    X_old=X;

   
     
 E=repmat(Best_X,n_PoP,1);   
 CF=rand*(1-Iter/M_Iter);
                             
 LD=levy(n_PoP,n_dim,1.5);   
 ND=randn(n_PoP,n_dim);         
           
  for i=1:size(X,1)
      SEL1=randi([1 i],1);
      SEL2=randi([1 i],1);
      
     for j=1:size(X,2)        
       R=rand();
         
       if Iter<0.2*M_Iter 
                              
          X(i,j)=X(i,j)+(ND(i,j)*(rand*E(i,j)-X(i,j))); 
             
     
       elseif Iter>=0.2*M_Iter && Iter<=0.4*M_Iter 
          
         if i>size(X,1)/2
            
            X(i,j)=E(i,j)+CF*(ND(i,j)*(rand*E(i,j)-X(SEL1,j))); 
         else
               
            X(i,j)=X(i,j)+(LD(i,j)*(E(i,j)-LD(i,j)*X(SEL2,j)));  
         end  
         
      
       else 
           
          
           X(i,j)=E(i,j)+CF*(LD(i,j)*(LD(i,j)*X(SEL1,j)-X(SEL2,j)));  
    
       end  
      end                                         
  end    
        
    
  for i=1:size(X,1)  
        
    Flag4ub=X(i,:)>ub;  
    Flag4lb=X(i,:)<lb;  
    X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
  
    fit_val(i,1)=Obj_Func(X(i,:));
        
      if fit_val(i,1)<Best_fit 
         Best_fit=fit_val(i,1);
         Best_X=X(i,:);
      end     
  end
        
   
    
 if Iter==0
    fit_old=fit_val;    X_old=X;
 end
     
    Inx=(fit_old<fit_val);
    Indx=repmat(Inx,1,n_dim);
    X=Indx.*X_old+~Indx.*X;
    fit_val=Inx.*fit_old+~Inx.*fit_val;
        
    fit_old=fit_val;    X_old=X;

  
                             
  if rand()<0.2
                                                                                           
     X=X+rand*(CF*XL+rand(n_PoP,n_dim).*(XU-XL));


  else
     r=rand();  XS=size(X,1);
     X=X+rand*rand*(X(randperm(XS),:)-X(randperm(XS),:));
  end
                                                        
  Iter=Iter+1;  
  Conv_Curve(Iter)=Best_fit; 
       disp(['Iter ', num2str(Iter), ': ', num2str(Conv_Curve(Iter))]);
end



function Positions=initialization(n_PoP,n_dim,ub,lb)

B_S= size(ub,2); 

if B_S==1
     Positions=rand(n_PoP,n_dim).*(ub-lb)+lb;
end


if B_S>1
    for i=1:n_dim
        ub_i=ub(i);
        lb_i=lb(i);
         Positions(:,i)=rand(n_PoP,1).*(ub_i-lb_i)+lb_i;      
    end
end
end


function [z] = levy(n,m,beta)

    num = gamma(1+beta)*sin(pi*beta/2); 
    
    den = gamma((1+beta)/2)*beta*2^((beta-1)/2); 

    sigma_u = (num/den)^(1/beta);

    u = random('Normal',0,sigma_u,n,m); 
    
    v = random('Normal',0,1,n,m);

    z =u./(abs(v).^(1/beta));

  
  end

  function z=sphere(x)
    z=sum(x.^2);
  end
