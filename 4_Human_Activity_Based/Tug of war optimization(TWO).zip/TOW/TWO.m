function TWO
    % Parameters
    numSolutions = 30; % Number of solutions (players)
    maxIterations = 100; % Maximum number of iterations
    dim = 2; % Dimensionality of the problem
    lowerBound = -10; % Lower bound of the search space
    upperBound = 10; % Upper bound of the search space

    % Initialize solutions randomly
    solutions = lowerBound + (upperBound - lowerBound) * rand(numSolutions, dim);
    fitness = arrayfun(@objectiveFunction, solutions);

    % Main optimization loop
    for iter = 1:maxIterations
        % Divide solutions into two teams
        teamA = solutions(1:numSolutions/2, :);
        teamB = solutions(numSolutions/2 + 1:end, :);

        % Calculate forces for each team
        fitnessA = fitness(1:numSolutions/2);
        fitnessB = fitness(numSolutions/2 + 1:end);

        % Normalizing fitness to represent forces
        forceA = fitnessA / sum(fitnessA);
        forceB = fitnessB / sum(fitnessB);

        % Update solutions
        for i = 1:numSolutions
            if i <= numSolutions/2
                % Solutions in Team A
                resultantForce = sum(forceB) - sum(forceA);
                solutions(i, :) = solutions(i, :) + resultantForce * rand(1, dim);
            else
                % Solutions in Team B
                resultantForce = sum(forceA) - sum(forceB);
                solutions(i, :) = solutions(i, :) + resultantForce * rand(1, dim);
            end

            % Boundary constraints
            solutions(i, :) = max(min(solutions(i, :), upperBound), lowerBound);
        end

        % Evaluate new fitness
        fitness = arrayfun(@objectiveFunction, solutions);

        % Track best solution
        [bestFitness, bestIndex] = min(fitness);
        bestSolution = solutions(bestIndex, :);

        % Display progress
        disp(['Iteration ' num2str(iter) ': Best Fitness = ' num2str(bestFitness)]);
    end

    % Output final best solution
    disp('Best Solution Found:');
    disp(bestSolution);
    disp(['Best Fitness: ' num2str(bestFitness)]);
end

% Objective function (example: Sphere function)
function f = objectiveFunction(x)
    f = sum(x.^2);
end
