function TugOfWarOptimization
    % Initialize parameters
    N = 30; % Number of candidate solutions
    maxIterations = 100; % Maximum number of iterations
    dim = 2; % Dimensionality of the problem
    lowerBound = -10; % Lower bound of the search space
    upperBound = 10; % Upper bound of the search space

    % Initialize a population of N random candidate solutions
    solutions = lowerBound + (upperBound - lowerBound) * rand(N, dim);
    league = solutions; % Initialize the league

    % Main optimization loop
    for iter = 1:maxIterations
        % Evaluate the objective function values for the candidate solutions
        fitness = arrayfun(@objectiveFunction, solutions);

        % Sort solutions and update the league based on fitness
        [fitness, sortedIndices] = sort(fitness);
        league = solutions(sortedIndices, :);

        % Calculate weights of the teams based on fitness
        weights = 1 ./ (1 + fitness); % Inverse of fitness to use as weights

        % Loop through each team
        for i = 1:N
            for j = 1:N
                if i ~= j && weights(i) < weights(j)
                    % Move team i towards team j using Eq. (9)
                    % Eq. (9): Displacement = rand * (league(j) - league(i))
                    displacement = rand * (league(j, :) - league(i, :));
                    solutions(i, :) = solutions(i, :) + displacement;
                end
            end

            % Use the side constraint handling technique to regenerate violating variables
            solutions(i, :) = max(min(solutions(i, :), upperBound), lowerBound);
        end

        % Display progress
        disp(['Iteration ' num2str(iter) ': Best Fitness = ' num2str(min(fitness))]);
    end

    % Output the best solution found
    [bestFitness, bestIndex] = min(fitness); % Get the minimum fitness and its index
    bestSolution = solutions(bestIndex, :);  % Select the solution corresponding to the best fitness
    disp('Best Solution Found:');
    disp(bestSolution);
    disp(['Best Fitness: ' num2str(bestFitness)]);
end

% Objective function (example: Sphere function)
function f = objectiveFunction(x)
    f = sum(x.^2);
end
