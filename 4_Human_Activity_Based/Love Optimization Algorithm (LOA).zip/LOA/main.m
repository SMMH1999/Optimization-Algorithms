% Define the objective function (Sphere function)
objective_function = @(x) sum(x.^2);

% Set up the parameters
lb = -10; % Lower bound
ub = 10;  % Upper bound
population_size = 20; % Population size
max_iter = 100; % Maximum number of iterations

% Call the LOA algorithm
[best_solution, best_fitness] = LOA(objective_function, lb, ub, population_size, max_iter);

% Display the result
disp(['Best Solution: ', num2str(best_solution)]);
disp(['Best Fitness: ', num2str(best_fitness)]);
function [best_solution, best_fitness] = LOA(objective_function, lb, ub, population_size, max_iter)
    % Initialize the population
    population = rand(population_size, numel(lb)) .* (ub - lb) + lb;
    
    % Evaluate the fitness of the population
    fitness = zeros(population_size, 1);
    for i = 1:population_size
        fitness(i) = objective_function(population(i, :));
    end
    
    % Find the best solution and fitness
    [best_fitness, idx] = min(fitness);
    best_solution = population(idx, :);
    
    % Main loop
    for iter = 1:max_iter
        % Calculate attraction values
        attraction = zeros(population_size, 1);
        for i = 1:population_size
            attraction(i) = 1 / (1 + fitness(i));
        end
        
        % Sort individuals based on attraction values
        [~, sorted_indices] = sort(attraction, 'descend');
        
        % Update individuals based on attraction
        for i = 1:population_size
            if i <= population_size * 0.1 % Top 10% individuals
                population(sorted_indices(i), :) = population(sorted_indices(i), :) + rand() * (best_solution - population(sorted_indices(i), :));
            else % Randomly selected individuals
                j = randi([1, population_size]);
                population(sorted_indices(i), :) = population(sorted_indices(i), :) + rand() * (population(j, :) - population(sorted_indices(i), :));
            end
            
            % Bound the positions
            population(sorted_indices(i), :) = max(population(sorted_indices(i), :), lb);
            population(sorted_indices(i), :) = min(population(sorted_indices(i), :), ub);
            
            % Evaluate the fitness of the updated individual
            fitness(sorted_indices(i)) = objective_function(population(sorted_indices(i), :));
        end
        
        % Update the best solution and fitness
        [current_best_fitness, idx] = min(fitness);
        if current_best_fitness < best_fitness
            best_fitness = current_best_fitness;
            best_solution = population(idx, :);
        end
        
        % Display the iteration information
        disp(['Iteration ', num2str(iter), ': Best Fitness = ', num2str(best_fitness)]);
    end
end
