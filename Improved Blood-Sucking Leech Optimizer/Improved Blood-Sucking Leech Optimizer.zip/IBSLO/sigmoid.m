% 定义sigmoid函数
function y = sigmoid(x)
    y = 1 ./ (1 + exp(-x));
end